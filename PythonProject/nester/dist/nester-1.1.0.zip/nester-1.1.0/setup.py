from distutils.core import setup

setup(
        name     = 'nester',
        version  = '1.1.0',
        py_modules=['nester'],
        author  ='qiulin',
        author_email='312578838@163.com',
        url         ='http://www.baidu.com',
        description ='A simple printer of nested lists',
      )
