from distutils.core import setup

setup(
        name     = 'sketch',
        version  = '1.0.0',
        py_modules=['sketch'],
        author  ='qiulin',
        author_email='312578838@163.com',
        url         ='http://www.baidu.com',
        description ='A simple test of sketch',
      )
